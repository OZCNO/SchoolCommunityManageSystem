// var psdFlag=true;
// var repsdFlag=true;
// var snoFlag=true;

function reset(){
	document.getElementsByTagName("input").value="";
}
// function psdTip(){
// 	var tip=document.getElementsByClassName("errorTip")[0];
// 	tip.innerHTML="请输入6-12位密码,只能包含数字，字母，下划线";
// 	tip.style.color="#222";
// }
// function repsdTip(){
// 	var tip=document.getElementsByClassName("errorTip")[0];
// 	tip.innerHTML="请再次输入密码";
// 	tip.style.color="#222";
// }
function checkSno(){
	// var tip=document.getElementsByClassName("errorTip")[0];
	var sno=document.getElementsByName("sno")[0].value;
	var reg=/^[1-9][0-9]{8}$/;
	// if(sno==""||sno==null) return false;
	if(!reg.test(sno)){
		// tip.innerHTML="学号格式错误";
		// alert("学号格式错误");
		// snoFlag=false;
		return false;
	}
	// tip.innerHTML="";
	// snoFlag=true;
	return true;
	// check();
}
function checkPsd(){
	// var tip=document.getElementsByClassName("errorTip")[0];
	var psd=document.getElementsByName("psd")[0].value;
	var reg=/^\w{6,12}/;
	// tip.style.color="red";
	// tip.innerHTML="";
	// if(psd==""||psd==null) return false;
	if(!reg.test(psd)){
		// tip.innerHTML="密码只能包含6~12位数字/字母/下划线";
		// alert("密码只能包含6~12位数字/字母/下划线");
		// psdFlag=false;
		return false;
	}
	// tip.innerHTML="";
	// psdFlag=true;
	return true;
	// check();
}
function checkRepsd(){
	// var tip=document.getElementsByClassName("errorTip")[0];
	var psd=document.getElementsByName("psd")[0].value;
	var repsd=document.getElementsByClassName("repsd")[0].value;
	// tip.style.color="red";
	// tip.innerHTML="";
	// if(repsd==""||repsd==null) return false;
	if(psd!==repsd){
		// tip.innerHTML="密码不一致";
		// alert("密码不一致");
		// repsdFlag=false;
		return false;
	}
	// tip.innerHTML="";
	// repsdFlag=true;
	return true;
	// check();
}
function checkPhone(){
	var phone=document.getElementsByName("phone")[0].value;
	var reg=/^1[345678]{1}[0-9]{9}$/;
	// if(phone==""||phone==null) return false;
	if(!reg.test(phone))	return false;
	return true;
}
function check(){
	// var tip=document.getElementsByClassName("errorTip")[0];
	if(!checkSno()){
		// tip.innerHTML="学号格式错误";
		alert("学号格式错误");
		return false;
	}
	if(!checkPsd()){
		// tip.innerHTML="密码只能包含6~12位数字/字母/下划线";
		alert("密码只能包含6~12位数字/字母/下划线");
		return false;
	}
	if(!checkRepsd()){
		// tip.innerHTML="密码不一致";
		alert("密码不一致");
		return false;
	}
	if(!checkPhone()){
		alert("手机格式错误");
		return false;
	}
	return true;
}